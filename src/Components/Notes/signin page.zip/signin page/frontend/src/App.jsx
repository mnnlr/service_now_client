import React from 'react'
import Navbar from './components/navbar'
import { Navigate, Route, Routes } from 'react-router-dom'
import Signin from './components/signin'
import Signup from './components/signup'
import { Toaster } from 'react-hot-toast';
import { useAuthContext } from './context/AuthContext'
import Home from './components/Home'


const App = () => {
  const { authUser } = useAuthContext()
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path='/login' element={authUser ? <Navigate to='/' /> : <Signin />} />
        <Route path='/signup' element={authUser ? <Navigate to='/' /> :<Signup />} />
        <Route path='/' element={authUser ? <Home /> : <Navigate to='/login' />} />
      </Routes>
      <Toaster />
    </div>
  )
}

export default App