import React from 'react'
import { Link } from 'react-router-dom'
import LoginHook from '../hooks/LoginHook'

const Signin = () => {
  const [formData, setFormData] = React.useState([])
  const { loading, Login } = LoginHook()

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value })
  }

  console.log(formData)

  const handleSubmit = async (e) => {
    e.preventDefault()
    await Login(formData)
  }

  return (
    <div className='h-[80vh] flex items-center '>
      <div className='mx-auto w-[18rem] md:w-[27rem]  p-4  md:p-8 bg-[#ECDFCC] rounded-md space-y-10 form'>

        <h1 className='text-2xl font-bold'>Log In With Your Mnnlr ID Now</h1>

        <form className='flex flex-col gap-4 mt-4 space-y-2 '
          onSubmit={handleSubmit}
        >
          <input
            required
            id='email'
            onChange={handleChange}
            type='email' placeholder='Email'
            className='p-2 outline-none border-2 hover:border-[#7A1CAC] rounded-md form' />

          <input
            required
            id='password'
            onChange={handleChange}
            type='password'
            placeholder='Password'
            className='p-2 outline-none border-2 hover:border-[#7A1CAC] rounded-md' />

          <button type='submit' className={`bg-[#7A1CAC] text-white p-2 rounded-md ${loading ? 'flex justify-center' : ''}`}
            disabled={loading}
            onClick={handleSubmit}
          >{loading ? <div className='loader'></div> : 'Log in'}</button>
        </form>

        <div>
          <p className='mt-4'>Don't have an account?  <Link to='/signup' className='text-[#7A1CAC] cursor-pointer' >Sign up</Link></p>
        </div>

      </div>

    </div>
  )
}

export default Signin