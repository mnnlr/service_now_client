import React from 'react'
import { Link } from 'react-router-dom'
import SignupHook from '../hooks/SignupHook'

const Signup = () => {
    const [formData, setFormData] = React.useState([])
    const { loading, Signup } = SignupHook()

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value })
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        await Signup(formData)
    }
    return (
        <div className='h-[80vh] flex items-center'>
            <div className='mx-auto w-[18rem] md:w-[27rem] p-4 md:p-8 bg-[#ECDFCC] rounded-md space-y-10 form'>

                <h1 className='text-2xl font-bold'>Sign Up For Mnnlr ID Now</h1>

                <form
                    onSubmit={handleSubmit}
                    className='flex flex-col gap-4 mt-4 space-y-2'>
                    <input id='name' onChange={handleChange} type='name' placeholder='Full name' className='p-2 outline-none border-2 hover:border-[#7A1CAC] rounded-md' />
                    <input id='email' onChange={handleChange} type='email' placeholder='Email' className='p-2 outline-none border-2 hover:border-[#7A1CAC] rounded-md ' />
                    <input id='password' onChange={handleChange} type='password' placeholder='Password' className='p-2 outline-none border-2 hover:border-[#7A1CAC] rounded-md' />
                    <button
                        disabled={loading}
                        onClick={handleSubmit}
                        type='submit' className={`bg-[#7A1CAC] text-white p-2 rounded-md ${loading ? 'flex justify-center' : ''}`}>{loading ? <div className='loader'></div> : 'Sign up'}</button>
                </form>

                <div>
                    <p className='mt-4'>Already have an account?  <Link to='/login' className='text-[#7A1CAC] cursor-pointer'>log in</Link></p>
                </div>

            </div>

        </div>
    )
}

export default Signup