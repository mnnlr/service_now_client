import React from 'react'

const Home = () => {
  return (
    <div className='h-screen flex items-center justify-center bg-black text-white text-4xl '>Welcome to Home page</div>
  )
}

export default Home